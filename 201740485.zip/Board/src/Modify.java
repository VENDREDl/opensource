import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JPopupMenu;
import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.JEditorPane;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTextField;
import javax.swing.DropMode;
import javax.swing.JSpinner;
import javax.swing.JScrollPane;

public class Modify extends JFrame {

	private JPanel contentPane;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Modify frame = new Modify();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Modify() {
		setTitle("\uAE00\uC218\uC815");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 400, 400);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnNewMenu = new JMenu("\uC124\uC815");
		mnNewMenu.setFont(new Font("���� ����", Font.BOLD, 12));
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("\uB0B4 \uC815\uBCF4");
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new Profile().setVisible(true);
			}
		});
		mntmNewMenuItem.setFont(new Font("���� ����", Font.BOLD, 12));
		mnNewMenu.add(mntmNewMenuItem);
		
		JMenu mnNewMenu_1 = new JMenu("\uC774\uB3D9");
		mnNewMenu_1.setFont(new Font("���� ����", Font.BOLD, 12));
		menuBar.add(mnNewMenu_1);
		
		JMenuItem mntmNewMenuItem_1 = new JMenuItem("\uAC8C\uC2DC\uD310");
		mntmNewMenuItem_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new Main().setVisible(true);
			}
		});
		mntmNewMenuItem_1.setFont(new Font("���� ����", Font.BOLD, 12));
		mnNewMenu_1.add(mntmNewMenuItem_1);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 68, 384, 270);
		contentPane.add(scrollPane);
		
		JEditorPane editorPane = new JEditorPane();
		scrollPane.setViewportView(editorPane);
		
		JButton btnNewButton = new JButton("\uC644\uB8CC");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new Main().setVisible(true);
			}
		});
		btnNewButton.setFont(new Font("����", Font.BOLD, 12));
		btnNewButton.setBounds(315, 0, 69, 48);
		contentPane.add(btnNewButton);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setFont(new Font("����", Font.BOLD, 12));
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"\uCE74\uD14C\uACE0\uB9AC", "\uAC1C\uBC1C", "\uBB38\uC758"}));
		comboBox.setBounds(298, 47, 86, 23);
		contentPane.add(comboBox);
		
		textField = new JTextField();
		textField.setFont(new Font("����", Font.BOLD, 12));
		textField.setToolTipText("\uC81C\uBAA9\uC744 \uC785\uB825\uD558\uC138\uC694.");
		textField.setBounds(0, 47, 298, 23);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton modifyCancel = new JButton("\uCDE8\uC18C");
		modifyCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new Read().setVisible(true);
			}
		});
		modifyCancel.setFont(new Font("����", Font.BOLD, 12));
		modifyCancel.setBounds(248, 0, 68, 48);
		contentPane.add(modifyCancel);
		
		JSpinner spinner = new JSpinner();
		spinner.setBounds(354, 68, 30, 22);
		contentPane.add(spinner);
	}

	private static void addPopup(Component component, final JPopupMenu popup) {
		component.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				if (e.isPopupTrigger()) {
					showMenu(e);
				}
			}
			public void mouseReleased(MouseEvent e) {
				if (e.isPopupTrigger()) {
					showMenu(e);
				}
			}
			private void showMenu(MouseEvent e) {
				popup.show(e.getComponent(), e.getX(), e.getY());
			}
		});
	}
}
