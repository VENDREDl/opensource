import java.awt.Component;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.AbstractButton;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class Write extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	protected AbstractButton jintent;
	protected JComboBox combobox;
	protected JComboBox comboBox;
	static String driver, url;
	static Connection conn;
	static Statement stmt;
	static ResultSet rs;

	/**
	 * Launch the application.
	 */
	public static void dbConnect() {
    	driver = "sun.jdbc.odbc.JdbcOdbcDriver";
    	try{
    		Class.forName("com.mysql.jdbc.Driver");
    		System.out.println("����̹� �˻� ����!");        
    	}catch(ClassNotFoundException e){
    		System.err.println("error = " + e);
    	}
        
    	
        url = "jdbc:odbc:board";
        conn = null;
        stmt = null;
        rs = null;
        String url = "jdbc:mysql://localhost/board?useUnicode=true&characterEncoding=utf8";
        String sql = "Select * From boardmain";
		try {
         
            conn = DriverManager.getConnection(url,"root","apmsetup");

            stmt = conn.createStatement( );

            rs = stmt.executeQuery(sql);
            
            System.out.println("�����ͺ��̽� ���� ����!");            
         
        }
        catch(Exception e) {
            System.out.println("�����ͺ��̽� ���� ����!");
        }
	}

	public static void query(String order, String sql) throws SQLException {
		if (order == "select") {
			rs = stmt.executeQuery(sql);
		} 
		else {
			stmt.executeUpdate(sql);
		}
	}

	/**
	 * Create the frame.
	 */
	public Write() {
		setTitle("\uAE00\uC4F0\uAE30");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 400, 400);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnNewMenu = new JMenu("\uC124\uC815");
		mnNewMenu.setFont(new Font("���� ����", Font.BOLD, 12));
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("\uB0B4 \uC815\uBCF4");
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new Profile().setVisible(true);
			}
		});
		mntmNewMenuItem.setFont(new Font("���� ����", Font.BOLD, 12));
		mnNewMenu.add(mntmNewMenuItem);
		
		JMenu mnNewMenu_1 = new JMenu("\uC774\uB3D9");
		mnNewMenu_1.setFont(new Font("���� ����", Font.BOLD, 12));
		menuBar.add(mnNewMenu_1);
		
		JMenuItem mntmNewMenuItem_1 = new JMenuItem("\uAC8C\uC2DC\uD310");
		mntmNewMenuItem_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
//				setVisible(false);
//				new Main().setVisible(true);
			}
		});
		mntmNewMenuItem_1.setFont(new Font("���� ����", Font.BOLD, 12));
		mnNewMenu_1.add(mntmNewMenuItem_1);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 68, 384, 270);
		contentPane.add(scrollPane);
		
		JEditorPane jintent = new JEditorPane();
		scrollPane.setViewportView(jintent);
		
		JButton btnNewButton = new JButton("\uC644\uB8CC");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbConnect();
				String title = textField.getText();
				String intent = jintent.getText();
//				String combo = comboBox.getSelectedItem().toString();
				String combo = "����";
				
				SimpleDateFormat date = new SimpleDateFormat("yyyy�� MM�� dd��");
				Date now = new Date();
														
					try {																		
						query("insert", "insert into boardmain values('" + combo + "','" + title + "','" + Login.login + "', '" + date.format(now) + "', '" + intent + "')");
						JOptionPane.showMessageDialog(null, "��ϼ���!");	
					}					
					catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
					Board.dbDis();
					setVisible(false);
					new Main().setVisible(true);
				
			}
		});
		btnNewButton.setFont(new Font("����", Font.BOLD, 12));
		btnNewButton.setBounds(315, 0, 69, 48);
		contentPane.add(btnNewButton);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setFont(new Font("����", Font.BOLD, 12));
		comboBox.addItem("����");
		comboBox.addItem("����");
		comboBox.getSelectedItem();
		comboBox.setBounds(298, 47, 86, 23);
		contentPane.add(comboBox);
		
		textField = new JTextField();
		textField.setFont(new Font("����", Font.BOLD, 12));
		textField.setToolTipText("\uC81C\uBAA9\uC744 \uC785\uB825\uD558\uC138\uC694.");
		textField.setBounds(0, 47, 298, 23);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton_1 = new JButton("\uCDE8\uC18C");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new Main().setVisible(true);
			}
		});
		btnNewButton_1.setFont(new Font("����", Font.BOLD, 12));
		btnNewButton_1.setBounds(248, 0, 68, 48);
		contentPane.add(btnNewButton_1);
		
		JSpinner spinner = new JSpinner();
		spinner.setBounds(354, 68, 30, 22);
		contentPane.add(spinner);
	}

	private static void addPopup(Component component, final JPopupMenu popup) {
		component.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				if (e.isPopupTrigger()) {
					showMenu(e);
				}
			}
			public void mouseReleased(MouseEvent e) {
				if (e.isPopupTrigger()) {
					showMenu(e);
				}
			}
			private void showMenu(MouseEvent e) {
				popup.show(e.getComponent(), e.getX(), e.getY());
			}
		});
	}
}
