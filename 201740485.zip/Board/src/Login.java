import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import java.awt.Color;

public class Login extends JFrame {

	private JPanel contentPane;
	private JTextField loginIDText;
	private JPasswordField loginPWText;
	static String driver, url;
	static Connection conn;
	static Statement stmt;
	static ResultSet rs;
	static String id;
	static String pw;
	static String login;
	

	/**
	 * Launch the application.
	 */
	public static void dbConnect() {
    	driver = "sun.jdbc.odbc.JdbcOdbcDriver";
    	try{
    		Class.forName("com.mysql.jdbc.Driver");
    		System.out.println("����̹� �˻� ����!");        
    	}catch(ClassNotFoundException e){
    		System.err.println("error = " + e);
    	}
        
    	
        url = "jdbc:odbc:board";
        conn = null;
        stmt = null;
        rs = null;
        String url = "jdbc:mysql://localhost/board";
        String sql = "Select * From user";
		try {
         
            conn = DriverManager.getConnection(url,"root","apmsetup");

            stmt = conn.createStatement( );

            rs = stmt.executeQuery(sql);
            
            System.out.println("�����ͺ��̽� ���� ����!");            
         
        }
        catch(Exception e) {
            System.out.println("�����ͺ��̽� ���� ����!");
        }
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setTitle("\uAC8C\uC2DC\uD310 \uB85C\uADF8\uC778");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 400, 400);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel loginLabel = new JLabel("\uB85C\uADF8\uC778");
		loginLabel.setFont(new Font("����", Font.BOLD, 23));
		loginLabel.setHorizontalAlignment(SwingConstants.CENTER);
		loginLabel.setBounds(0, 0, 384, 67);
		contentPane.add(loginLabel);
		
		JLabel loginID = new JLabel("ID");
		loginID.setFont(new Font("����", Font.BOLD, 14));
		loginID.setHorizontalAlignment(SwingConstants.CENTER);
		loginID.setBounds(66, 134, 57, 15);
		contentPane.add(loginID);
		
		JLabel loginPW = new JLabel("PW");
		loginPW.setFont(new Font("����", Font.BOLD, 14));
		loginPW.setHorizontalAlignment(SwingConstants.CENTER);
		loginPW.setBounds(66, 184, 57, 15);
		contentPane.add(loginPW);
		
		loginIDText = new JTextField();
		loginIDText.setToolTipText("ID \uC785\uB825");
		loginIDText.setBounds(135, 128, 116, 21);
		contentPane.add(loginIDText);
		loginIDText.setColumns(10);
		
		JLabel loginText = new JLabel("");
		loginText.setHorizontalAlignment(SwingConstants.CENTER);
		loginText.setForeground(Color.RED);
		loginText.setFont(new Font("����", Font.BOLD, 14));
		loginText.setBounds(64, 276, 262, 21);
		contentPane.add(loginText);
		
		JButton loginBtn = new JButton("\uB85C\uADF8\uC778");
		loginBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbConnect();
				id = loginIDText.getText();
				pw = loginPWText.getText();
				
					String sql = "select * from user where id like '" + id + "'";
					try {
						rs = stmt.executeQuery(sql);
					if(rs.next()) {
						if(pw.equals(rs.getString("pw"))) {
							login =loginIDText.getText();

							JOptionPane.showMessageDialog(null, "ȯ���մϴ�.", "�α��� ����", JOptionPane.PLAIN_MESSAGE);
							setVisible(false);
							new Main().setVisible(true);
						}
						else if(!(pw.equals(rs.getString("pw")))) {
							JOptionPane.showMessageDialog(null, "��й�ȣ�� Ʋ�Ƚ��ϴ�.", "��й�ȣ ����", JOptionPane.WARNING_MESSAGE);
						}
						
												
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
					Board.dbDis();
			}
		});
		loginBtn.setFont(new Font("����", Font.BOLD, 14));
		loginBtn.setBounds(273, 134, 87, 59);
		contentPane.add(loginBtn);
		
		JButton loginReg = new JButton("\uD68C\uC6D0\uAC00\uC785 \uD558\uAE30");
		loginReg.setFont(new Font("����", Font.BOLD, 14));
		loginReg.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new Register().setVisible(true);
			}
		});
		loginReg.setBounds(66, 231, 248, 23);
		contentPane.add(loginReg);
		
		loginPWText = new JPasswordField();
		loginPWText.setBounds(135, 181, 116, 21);
		contentPane.add(loginPWText);
		
		
		
	}
}
