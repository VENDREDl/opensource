import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;

public class Register extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_3;
	private JPasswordField passwordField;
	private JPasswordField passwordField_1;
	static String driver, url;
	static Connection conn;
	static Statement stmt;
	static ResultSet rs;
	static String id;
	static String pw;
	static String email;
	static String pwre;

	/**
	 * Launch the application.
	 */
	public static void dbConnect() {
    	driver = "sun.jdbc.odbc.JdbcOdbcDriver";
    	try{
    		Class.forName("com.mysql.jdbc.Driver");
    		System.out.println("����̹� �˻� ����!");        
    	}catch(ClassNotFoundException e){
    		System.err.println("error = " + e);
    	}
        
    	
        url = "jdbc:odbc:board";
        conn = null;
        stmt = null;
        rs = null;
        String url = "jdbc:mysql://localhost/board";
        String sql = "Select * From user";
		try {
         
            conn = DriverManager.getConnection(url,"root","apmsetup");

            stmt = conn.createStatement( );

            rs = stmt.executeQuery(sql);
            
            System.out.println("�����ͺ��̽� ���� ����!");            
         
        }
        catch(Exception e) {
            System.out.println("�����ͺ��̽� ���� ����!");
        }
	}

	public static void query(String order, String sql) throws SQLException {
		if (order == "select") {
			rs = stmt.executeQuery(sql);
		} 
		else {
			stmt.executeUpdate(sql);
		}
	}

	/**
	 * Create the frame.
	 */
	public Register() {
		setTitle("\uD68C\uC6D0\uAC00\uC785");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 400, 400);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel regLabel = new JLabel("\uD68C\uC6D0\uAC00\uC785");
		regLabel.setHorizontalAlignment(SwingConstants.CENTER);
		regLabel.setFont(new Font("����", Font.BOLD, 23));
		regLabel.setBounds(0, 0, 384, 67);
		contentPane.add(regLabel);
		
		JLabel lblId = new JLabel("* ID");
		lblId.setFont(new Font("����", Font.BOLD, 14));
		lblId.setHorizontalAlignment(SwingConstants.CENTER);
		lblId.setBounds(67, 83, 57, 15);
		contentPane.add(lblId);
		
		JLabel lblPw = new JLabel("* PW");
		lblPw.setFont(new Font("����", Font.BOLD, 14));
		lblPw.setHorizontalAlignment(SwingConstants.CENTER);
		lblPw.setBounds(67, 133, 57, 15);
		contentPane.add(lblPw);
		
		textField = new JTextField();
		textField.setToolTipText("\uD544\uC218 \uC785\uB825 \uC815\uBCF4\uC785\uB2C8\uB2E4.");
		textField.setColumns(10);
		textField.setBounds(136, 77, 116, 21);
		contentPane.add(textField);
		
		JLabel lblPw_2 = new JLabel("* PW \uC7AC\uC785\uB825");
		lblPw_2.setFont(new Font("����", Font.BOLD, 14));
		lblPw_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblPw_2.setBounds(40, 182, 84, 15);
		contentPane.add(lblPw_2);
		
		textField_3 = new JTextField();
		textField_3.setToolTipText("\uD544\uC218 \uC785\uB825 \uC815\uBCF4\uC785\uB2C8\uB2E4.");
		textField_3.setColumns(10);
		textField_3.setBounds(136, 225, 116, 21);
		contentPane.add(textField_3);
		
		JLabel lblEmail = new JLabel("EMAIL");
		lblEmail.setHorizontalAlignment(SwingConstants.CENTER);
		lblEmail.setFont(new Font("����", Font.BOLD, 14));
		lblEmail.setBounds(67, 231, 57, 15);
		contentPane.add(lblEmail);
		
		JButton regConfirm = new JButton("\uD68C\uC6D0\uAC00\uC785");
		regConfirm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbConnect();
				id = textField.getText();
				pw = passwordField.getText();
				pwre = passwordField_1.getText();
				email = textField_3.getText();
				
				if(pw.equals(pwre)) {		
					try {
						query("insert", "insert into user values('" + id + "','" + pw + "','" + email + "')");
						JOptionPane.showMessageDialog(null, "ȸ������ ����!");
						setVisible(false);
						new Login().setVisible(true);
					}
					catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				}
				else {
						JOptionPane.showMessageDialog(null, "��й�ȣ�� ��ġ ���� ����.");
					
				}
				
					Board.dbDis();
			}
		});
		regConfirm.setFont(new Font("����", Font.BOLD, 14));
		regConfirm.setBounds(73, 267, 116, 34);
		contentPane.add(regConfirm);
		
		JButton regCancel = new JButton("\uCDE8\uC18C");
		regCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new Login().setVisible(true);
			}
		});
		regCancel.setFont(new Font("����", Font.BOLD, 14));
		regCancel.setBounds(201, 267, 116, 34);
		contentPane.add(regCancel);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(136, 130, 116, 21);
		contentPane.add(passwordField);
		
		passwordField_1 = new JPasswordField();
		passwordField_1.setBounds(136, 179, 116, 21);
		contentPane.add(passwordField_1);
	}

}
