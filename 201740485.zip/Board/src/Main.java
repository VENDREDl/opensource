import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import java.awt.ScrollPane;
import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextField;

public class Main extends JFrame {

	private JPanel contentPane;
	private JTable table;
	protected static Object saveTitle;
	static String driver, url;
	static Connection conn;
	static Statement stmt;
	static ResultSet rs;
	static String getTitle;
	static String getWriter;
	static String getDate;
	static String getIntent;
	private JTextField textField;
	private JTextField svTitle;
	

	/**
	 * Launch the application.
	 */
	public static void dbConnect() {
    	driver = "sun.jdbc.odbc.JdbcOdbcDriver";
    	try{
    		Class.forName("com.mysql.jdbc.Driver");
    		System.out.println("����̹� �˻� ����!");        
    	}catch(ClassNotFoundException e){
    		System.err.println("error = " + e);
    	}
        
    	
        url = "jdbc:odbc:board";
        conn = null;
        stmt = null;
        rs = null;
        String url = "jdbc:mysql://localhost/board?useUnicode=true&characterEncoding=utf8";
        String sql = "Select * From boardmain";
		try {
         
            conn = DriverManager.getConnection(url,"root","apmsetup");

            stmt = conn.createStatement( );

            rs = stmt.executeQuery(sql);
            
            System.out.println("�����ͺ��̽� ���� ����!");            
         
        }
        catch(Exception e) {
            System.out.println("�����ͺ��̽� ���� ����!");
        }
	}

	public static void query(String order, String sql) throws SQLException {
		if (order == "select") {
			rs = stmt.executeQuery(sql);
		} 
		else {
			stmt.executeUpdate(sql);
		}
	}

	/**
	 * Create the frame.
	 */
	public Main() {
		setTitle("\uAC8C\uC2DC\uD310");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 872, 475);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnNewMenu = new JMenu("\uC124\uC815");
		mnNewMenu.setFont(new Font("���� ����", Font.BOLD, 12));
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("\uB0B4 \uC815\uBCF4");
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new Profile().setVisible(true);
			}
		});
		mntmNewMenuItem.setFont(new Font("���� ����", Font.BOLD, 12));
		mnNewMenu.add(mntmNewMenuItem);
		
		JMenuItem mntmNewMenuItem_2 = new JMenuItem("\uB85C\uADF8\uC544\uC6C3");
		mntmNewMenuItem_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new Login().setVisible(true);
			}
		});
		mntmNewMenuItem_2.setFont(new Font("���� ����", Font.BOLD, 12));
		mnNewMenu.add(mntmNewMenuItem_2);
		
		JMenu mnNewMenu_1 = new JMenu("\uC774\uB3D9");
		mnNewMenu_1.setFont(new Font("���� ����", Font.BOLD, 12));
		menuBar.add(mnNewMenu_1);
		
		JMenuItem mntmNewMenuItem_1 = new JMenuItem("\uAC8C\uC2DC\uD310");
		mntmNewMenuItem_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				setVisible(true);
			}
		});
		
		
		mntmNewMenuItem_1.setFont(new Font("���� ����", Font.BOLD, 12));
		mnNewMenu_1.add(mntmNewMenuItem_1);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"\uC804\uCCB4", "\uBB38\uC758", "\uAC1C\uBC1C"}));
		comboBox.setMaximumRowCount(3);
		comboBox.setFont(new Font("����", Font.BOLD, 12));
		comboBox.setBounds(744, 10, 100, 23);
		contentPane.add(comboBox);
		
		JLabel lblNewLabel = new JLabel("\uCE74\uD14C\uACE0\uB9AC");
		lblNewLabel.setFont(new Font("����", Font.BOLD, 12));
		lblNewLabel.setBounds(686, 14, 57, 15);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("\uAE00\uC4F0\uAE30");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new Write().setVisible(true);
			}
		});
		btnNewButton.setBackground(new Color(255, 255, 255));
		btnNewButton.setFont(new Font("����", Font.BOLD, 12));
		btnNewButton.setBounds(12, 10, 76, 23);
		contentPane.add(btnNewButton);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(12, 55, 832, 348);
		contentPane.add(scrollPane_1);
		
		JLabel saveWriter = new JLabel("New label");
		saveWriter.setEnabled(false);
		saveWriter.setBounds(118, 32, 1, 1);
		contentPane.add(saveWriter);
		
		JLabel saveDate = new JLabel("New label");
		saveDate.setEnabled(false);
		saveDate.setBounds(156, 14, 1, 1);
		contentPane.add(saveDate);
		
		JLabel saveIntent = new JLabel("New label");
		saveIntent.setEnabled(false);
		saveIntent.setBounds(156, 32, 1, 1);
		contentPane.add(saveIntent);
		
		String[] head = {"ī�װ���", "����", "����", "�۾���", "�ۼ���"};
		DefaultTableModel model = new DefaultTableModel(head, 0);
		try {
			dbConnect();
			query("select", "select * from boardmain");
			while(rs.next()) {
				model.addRow(new Object[] {rs.getString("bCategory"),
											rs.getString("bTitle"),
											rs.getString("bIntent"),
											rs.getString("bWriter"),
											rs.getString("bDate")			
				});
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		Board.dbDis();
		
		table = new JTable(model);
		scrollPane_1.setViewportView(table);
		
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int row = table.getSelectedRow();
				TableModel data = table.getModel();
				String id = (String)data.getValueAt(row, 1);
				dbConnect();
				try {
					query("select", "select * from boardmain where bTitle like '" + id + "'");
					if(rs.next()) {
						svTitle.setText(rs.getString("bTitle"));
						saveWriter.setText(rs.getString("bWriter"));
						saveDate.setText(rs.getString("bDate"));
						saveIntent.setText(rs.getString("bIntent"));	
						
						getTitle = svTitle.getText();
						getWriter = saveWriter.getText();
						getDate = saveDate.getText();
						getIntent = saveIntent.getText();
					}
					
					setVisible(false);
					new Read().setVisible(true);
						
				}
				catch(SQLException e1) {
					e1.printStackTrace();
				}
				Board.dbDis();
			}
		});
		table.setFont(new Font("����", Font.PLAIN, 12));
		scrollPane_1.setViewportView(table);
		
		svTitle = new JTextField();
		svTitle.setBounds(139, 11, 1, 1);
		contentPane.add(svTitle);
		svTitle.setColumns(10);
		
		
		
	}
}
