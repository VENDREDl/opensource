import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import java.awt.Font;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JEditorPane;
import javax.swing.JTextPane;
import javax.swing.SwingConstants;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JButton;

public class Read extends JFrame {

	private JPanel contentPane;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField;
	static String driver, url;
	static Connection conn;
	static Statement stmt;
	static ResultSet rs;
	/**
	 * Launch the application.
	 */
	public static void dbConnect() {
    	driver = "sun.jdbc.odbc.JdbcOdbcDriver";
    	try{
    		Class.forName("com.mysql.jdbc.Driver");
    		System.out.println("����̹� �˻� ����!");        
    	}catch(ClassNotFoundException e){
    		System.err.println("error = " + e);
    	}
        
    	
        url = "jdbc:odbc:board";
        conn = null;
        stmt = null;
        rs = null;
        String url = "jdbc:mysql://localhost/board?useUnicode=true&characterEncoding=utf8";
        String sql = "Select * From boardmain";
		try {
         
            conn = DriverManager.getConnection(url,"root","apmsetup");

            stmt = conn.createStatement( );

            rs = stmt.executeQuery(sql);
            
            System.out.println("�����ͺ��̽� ���� ����!");            
         
        }
        catch(Exception e) {
            System.out.println("�����ͺ��̽� ���� ����!");
        }
	}

	public static void query(String order, String sql) throws SQLException {
		if (order == "select") {
			rs = stmt.executeQuery(sql);
		} 
		else {
			stmt.executeUpdate(sql);
		}
	}

	/**
	 * Create the frame.
	 */
	public Read() {
		setTitle("\uAE00\uC77D\uAE30");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 400, 400);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(0, 0, 384, 23);
		contentPane.add(menuBar);
		
		JMenu mnNewMenu = new JMenu("\uC124\uC815");
		mnNewMenu.setFont(new Font("���� ����", Font.BOLD, 12));
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("\uB0B4 \uC815\uBCF4");
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new Profile().setVisible(true);
			}
		});
		mntmNewMenuItem.setFont(new Font("���� ����", Font.BOLD, 12));
		mnNewMenu.add(mntmNewMenuItem);
		
		JMenu mnNewMenu_1 = new JMenu("\uC774\uB3D9");
		mnNewMenu_1.setFont(new Font("���� ����", Font.BOLD, 12));
		menuBar.add(mnNewMenu_1);
		
		JMenuItem mntmNewMenuItem_1 = new JMenuItem("\uAC8C\uC2DC\uD310");
		mntmNewMenuItem_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new Main().setVisible(true);
			}
		});
		
	
		
							
			
			
			
		
		mntmNewMenuItem_1.setFont(new Font("���� ����", Font.BOLD, 12));
		mnNewMenu_1.add(mntmNewMenuItem_1);
		
		JTextPane textPane = new JTextPane();
		textPane.setText("\r\n");
		textPane.setEditable(false);
		textPane.setFont(new Font("����", Font.BOLD, 12));
		textPane.setBounds(0, 93, 384, 268);
		contentPane.add(textPane);
		
		textField_1 = new JTextField();
		textField_1.setHorizontalAlignment(SwingConstants.CENTER);
		textField_1.setToolTipText("");
		textField_1.setFont(new Font("����", Font.PLAIN, 12));
		textField_1.setEditable(false);
		textField_1.setColumns(10);
		textField_1.setBounds(60, 71, 85, 23);
		contentPane.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setEditable(false);
		textField_2.setToolTipText("");
		textField_2.setFont(new Font("����", Font.PLAIN, 12));
		textField_2.setColumns(10);
		textField_2.setBounds(0, 48, 298, 23);
		contentPane.add(textField_2);
		
		JLabel lblNewLabel = new JLabel("\uAE00\uC4F4\uC774");
		lblNewLabel.setFont(new Font("����", Font.BOLD, 12));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(0, 71, 57, 23);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\uC791\uC131\uC77C");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("����", Font.BOLD, 12));
		lblNewLabel_1.setBounds(150, 71, 63, 23);
		contentPane.add(lblNewLabel_1);
		
		textField = new JTextField();
		textField.setToolTipText("");
		textField.setHorizontalAlignment(SwingConstants.CENTER);
		textField.setFont(new Font("����", Font.PLAIN, 11));
		textField.setEditable(false);
		textField.setColumns(10);
		textField.setBounds(213, 71, 85, 23);
		contentPane.add(textField);
		
		JButton btnNewButton = new JButton("\uC218\uC815");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new Modify().setVisible(true);
			}
		});
		
		
		dbConnect();
			String sql = "select * from boardmain where bTitle like '" + Main.getTitle + "'";
			try {
				rs = stmt.executeQuery(sql);
			if(rs.next()) {
					textField_2.setText(rs.getString("bTitle"));
					textField_1.setText(rs.getString("bWriter"));
					textField.setText(rs.getString("bDate"));
					textPane.setText(rs.getString("bIntent"));
				}
				
												
			}
		 catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
			Board.dbDis();
		
		btnNewButton.setBounds(299, 22, 85, 37);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\uC0AD\uC81C");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String writer = textField_1.getText();
				String title = textField_2.getText();
				String writer2 = Login.login;
				
				dbConnect();

				if(writer.equals(writer2)) {		
					try {
						query("delete", "delete from boardmain where bTitle like ('" + title + "')");
						JOptionPane.showMessageDialog(null, "�Խù� ���� �Ϸ�");
						setVisible(false);
						new Main().setVisible(true);
					}
					catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				}
				else {
						JOptionPane.showMessageDialog(null, "������ �Խù��� �ƴմϴ�.");
					
				}
				
					Board.dbDis();
				
			}
		});
		btnNewButton_1.setBounds(299, 57, 85, 37);
		contentPane.add(btnNewButton_1);
	}
}
