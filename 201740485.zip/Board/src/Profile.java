import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import java.awt.Font;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class Profile extends JFrame {

	private JPanel contentPane;
	private JTextField txtAdmin;
	private JPasswordField passwordField;
	private JPasswordField passwordField_1;
	private JPasswordField passwordField_2;
	static String driver, url;
	static Connection conn;
	static Statement stmt;
	static ResultSet rs;
	static String id;
	static String pw;

	/**
	 * Launch the application.
	 */
	public static void dbConnect() {
    	driver = "sun.jdbc.odbc.JdbcOdbcDriver";
    	try{
    		Class.forName("com.mysql.jdbc.Driver");
    		System.out.println("����̹� �˻� ����!");        
    	}catch(ClassNotFoundException e){
    		System.err.println("error = " + e);
    	}
        
    	
        url = "jdbc:odbc:board";
        conn = null;
        stmt = null;
        rs = null;
        String url = "jdbc:mysql://localhost/board";
        String sql = "Select * From user";
		try {
         
            conn = DriverManager.getConnection(url,"root","apmsetup");

            stmt = conn.createStatement( );

            rs = stmt.executeQuery(sql);
            
            System.out.println("�����ͺ��̽� ���� ����!");            
         
        }
        catch(Exception e) {
            System.out.println("�����ͺ��̽� ���� ����!");
        }
	}

	public static void query(String order, String sql) throws SQLException {
		if (order == "select") {
			rs = stmt.executeQuery(sql);
		} 
		else {
			stmt.executeUpdate(sql);
		}
	}

	/**
	 * Create the frame.
	 */
	public Profile() {
		setTitle("\uB0B4 \uC815\uBCF4");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 400, 400);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(0, 0, 384, 23);
		contentPane.add(menuBar);
		
		JMenu mnNewMenu = new JMenu("\uC124\uC815");
		mnNewMenu.setFont(new Font("���� ����", Font.BOLD, 12));
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("\uB0B4 \uC815\uBCF4");
		mntmNewMenuItem.setFont(new Font("���� ����", Font.BOLD, 12));
		mnNewMenu.add(mntmNewMenuItem);
		
		JMenu mnNewMenu_1 = new JMenu("\uC774\uB3D9");
		mnNewMenu_1.setFont(new Font("���� ����", Font.BOLD, 12));
		menuBar.add(mnNewMenu_1);
		
		JMenuItem mntmNewMenuItem_1 = new JMenuItem("\uAC8C\uC2DC\uD310");
		mntmNewMenuItem_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new Main().setVisible(true);
			}
		});
		mntmNewMenuItem_1.setFont(new Font("���� ����", Font.BOLD, 12));
		mnNewMenu_1.add(mntmNewMenuItem_1);
		
		JLabel lblNewLabel = new JLabel("ID");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("����", Font.BOLD, 12));
		lblNewLabel.setBounds(53, 73, 57, 15);
		contentPane.add(lblNewLabel);
		
		txtAdmin = new JTextField();
		txtAdmin.setEditable(false);
		txtAdmin.setHorizontalAlignment(SwingConstants.CENTER);
		txtAdmin.setBounds(122, 70, 116, 21);
		contentPane.add(txtAdmin);
		txtAdmin.setColumns(10);
		
		JLabel lblPw = new JLabel("\uAE30\uC874 PW");
		lblPw.setHorizontalAlignment(SwingConstants.CENTER);
		lblPw.setFont(new Font("����", Font.BOLD, 12));
		lblPw.setBounds(53, 115, 57, 15);
		contentPane.add(lblPw);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(122, 112, 116, 21);
		contentPane.add(passwordField);
		
		JLabel lblPw_2 = new JLabel("\uBCC0\uACBD PW");
		lblPw_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblPw_2.setFont(new Font("����", Font.BOLD, 12));
		lblPw_2.setBounds(53, 155, 57, 15);
		contentPane.add(lblPw_2);
		
		passwordField_1 = new JPasswordField();
		passwordField_1.setBounds(122, 152, 116, 21);
		contentPane.add(passwordField_1);
		
		JLabel lblPw_2_1 = new JLabel("\uBCC0\uACBD PW \uC7AC\uC785\uB825");
		lblPw_2_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblPw_2_1.setFont(new Font("����", Font.BOLD, 12));
		lblPw_2_1.setBounds(27, 195, 90, 15);
		contentPane.add(lblPw_2_1);
		
		passwordField_2 = new JPasswordField();
		passwordField_2.setBounds(122, 192, 116, 21);
		contentPane.add(passwordField_2);
		
		dbConnect();
		String sql = "select * from user where id like '" + Login.login + "'";
		try {			
			rs = stmt.executeQuery(sql);
			
		if(rs.next()) {		
			txtAdmin.setText(rs.getString("id"));

			
										
		}
	} catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
		Board.dbDis();
		
		JButton btnNewButton = new JButton("\uC815\uBCF4 \uC218\uC815");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbConnect();
				pw = passwordField_1.getText();
				String pw1 = passwordField_2.getText();
										
					String sql = "select * from user where id like '" + Login.login + "'";
					
					try {			
						rs = stmt.executeQuery(sql);
						
					if(rs.next()) {		
						
						query("update", "update user set pw ='"+pw+"' where id like'" + Login.login + "'");
						JOptionPane.showMessageDialog(null, "�������� ����!");	
					}
					else
						JOptionPane.showMessageDialog(null, "�������� ����!");
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
					Board.dbDis();
			}
		});
		btnNewButton.setBounds(86, 305, 97, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\uD68C\uC6D0 \uD0C8\uD1F4");
		btnNewButton_1.setBounds(215, 305, 97, 23);
		contentPane.add(btnNewButton_1);
	}
}
