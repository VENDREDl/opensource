-- phpMyAdmin SQL Dump
-- version 3.2.3
-- http://www.phpmyadmin.net
--
-- 호스트: localhost
-- 처리한 시간: 20-11-28 16:38 
-- 서버 버전: 5.1.41
-- PHP 버전: 5.2.12

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 데이터베이스: `board`
--

-- --------------------------------------------------------

--
-- 테이블 구조 `boardmain`
--

CREATE TABLE IF NOT EXISTS `boardmain` (
  `bCategory` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `bTitle` varchar(100) NOT NULL,
  `bWriter` varchar(20) NOT NULL,
  `bDate` varchar(50) NOT NULL,
  `bIntent` varchar(300) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `boardmain`
--

INSERT INTO `boardmain` (`bCategory`, `bTitle`, `bWriter`, `bDate`, `bIntent`) VALUES
('개발', 'test', 'test', '2020년 11월 28일', 'test'),
('개발', '테스트', 'admin', '2020년 11월 28일', 'DB 연동 테스트');

-- --------------------------------------------------------

--
-- 테이블 구조 `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` varchar(20) NOT NULL,
  `pw` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- 테이블의 덤프 데이터 `user`
--

INSERT INTO `user` (`id`, `pw`, `email`) VALUES
('test', '1234', 'test@naver.com'),
('admin', 'admin', 'admin@google.com'),
('developer', '1234', 'node.js_@kakao.com'),
('123', '1234', '123'),
('dit', 'dit', ''),
('test1', 'test1', '');
